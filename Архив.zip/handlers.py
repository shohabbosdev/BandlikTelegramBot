from collections import Counter
from telegram import Update
from telegram.constants import ChatAction
from telegram.ext import ContextTypes

from config import REQUIRED_STATUS
from sheets import load_rows
from utils import safe_cell, escape_md
from keyboards import reply_main_menu, pagination_keyboard
from formatters import format_card, format_results_block

# Ustun indekslari (0-based)
HEMIS_UID    = 0   # A
IDX_HEMIS    = 2   # C
IDX_FIO      = 3   # D
IDX_STAT     = 4   # E
IDX_JSH      = 5   # F
IDX_W        = 22  # W
IDX_LAVOZIM  = 29  # AD
IDX_TASHKILOT= 30  # AE
IDX_SANASI   = 34  # AI

PER_PAGE = 10

# Chat bo‘yicha kesh
# chat_id -> {"query": str, "results": [dict,...], "page_msg_id": int or None}
CHAT_CACHE = {}

def _build_results(query: str, rows):
    """Matnga mos keluvchi yozuvlar ro'yxatini (dict) qaytaradi."""
    res = []
    q = query.strip().lower()
    if not q:
        return res

    for r in rows[1:]:
        hemisuid = safe_cell(r, HEMIS_UID)
        fio      = safe_cell(r, IDX_FIO)
        hemis    = safe_cell(r, IDX_HEMIS)
        jshshir  = safe_cell(r, IDX_JSH)
        status   = safe_cell(r, IDX_STAT)

        if not (fio or hemis or jshshir or hemisuid):
            continue

        if q in fio.lower() or q in hemis.lower() or q in jshshir.lower() or q in hemisuid.lower():
            item = {
                "hemisuid": hemisuid,
                "fio": fio,
                "hemis": hemis,
                "status": status,
                "jshshir": jshshir,
            }
            # Faol bo'lsa ish ma'lumotlari birga
            if REQUIRED_STATUS.lower() in status.lower():
                item["lavozim"]   = safe_cell(r, IDX_LAVOZIM)
                item["tashkilot"] = safe_cell(r, IDX_TASHKILOT)
                item["sanasi"]    = safe_cell(r, IDX_SANASI)
            res.append(item)
    return res

def _results_summary(results):
    """Jami natija va faol ulush protsentini qaytaradi: (total, active, active_pct)."""
    total = len(results)
    active = sum(1 for it in results if REQUIRED_STATUS.lower() in it.get("status","").lower())
    pct = round((active/total*100), 2) if total else 0.0
    return total, active, pct

async def _delete_prev_page_msg(chat_id: int, context: ContextTypes.DEFAULT_TYPE):
    """Agar avvalgi sahifa xabari bo'lsa — o‘chiradi."""
    cache = CHAT_CACHE.get(chat_id)
    if cache and cache.get("page_msg_id"):
        try:
            await context.bot.delete_message(chat_id=chat_id, message_id=cache["page_msg_id"])
        except Exception:
            pass
        cache["page_msg_id"] = None

async def _send_page(chat_id: int, context: ContextTypes.DEFAULT_TYPE, page: int):
    """Natijalarni yangi sahifa sifatida yuboradi (oldingi xabarni o‘chirib)."""
    cache = CHAT_CACHE.get(chat_id) or {}
    results = cache.get("results", [])
    total, active, pct = _results_summary(results)

    total_pages = max(1, (len(results) + PER_PAGE - 1) // PER_PAGE)
    page = max(1, min(page, total_pages))
    start = (page - 1) * PER_PAGE
    end = start + PER_PAGE
    page_items = results[start:end]

    header = (
        f"📋 *Jami natija:* {total} ta\n"
        f"🟢 *Faollar:* {active} ta ({pct}%)\n"
        f"📄 *Sahifa:* {page}/{total_pages}\n\n"
    )

    text = header + format_results_block(page_items)

    # Eski sahifani o'chiramiz
    await _delete_prev_page_msg(chat_id, context)

    sent = await context.bot.send_message(
        chat_id=chat_id,
        text=text,
        parse_mode="Markdown",
        reply_markup=pagination_keyboard(page, total_pages),
        disable_web_page_preview=True,
    )
    # Yangi xabar id ni saqlaymiz
    cache["page_msg_id"] = sent.message_id
    CHAT_CACHE[chat_id] = cache

async def _edit_page(callback_update: Update, context: ContextTypes.DEFAULT_TYPE, page: int):
    """Inline tugmalarda xabar ichini tahrirlaydi (chat toza qoladi)."""
    chat_id = callback_update.effective_chat.id
    cache = CHAT_CACHE.get(chat_id) or {}
    results = cache.get("results", [])
    total, active, pct = _results_summary(results)

    total_pages = max(1, (len(results) + PER_PAGE - 1) // PER_PAGE)
    page = max(1, min(page, total_pages))
    start = (page - 1) * PER_PAGE
    end = start + PER_PAGE
    page_items = results[start:end]

    header = (
        f"📋 *Jami natija:* {total} ta\n"
        f"🟢 *Faollar:* {active} ta ({pct}%)\n"
        f"📄 *Sahifa:* {page}/{total_pages}\n\n"
    )
    text = header + format_results_block(page_items)

    try:
        await callback_update.callback_query.edit_message_text(
            text=text,
            parse_mode="Markdown",
            reply_markup=pagination_keyboard(page, total_pages),
            disable_web_page_preview=True,
        )
    except Exception:
        # Agar edit bajarilmasa, yangisini yuboramiz (va eski sahifani o‘chirib yuboramiz)
        await _send_page(chat_id, context, page)

# /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    CHAT_CACHE.pop(update.effective_chat.id, None)  # bu chat uchun keshni tozalaymiz
    await update.message.reply_text(
        "👋 *Assalomu alaykum!*\n\n"
        "Ism/familiya (qismi ham bo‘ladi), HEMIS ID yoki JSHSHIR yuboring — men jadvaldan topib beraman.\n\n"
        "📌 Pastdagi tugmalardan foydalanishingiz mumkin:",
        parse_mode="Markdown",
        reply_markup=reply_main_menu()
    )

# /stat yoki reply tugma: “📊 Statistika”
async def stat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    await context.bot.send_chat_action(chat_id=chat_id, action=ChatAction.TYPING)

    rows = load_rows()
    if len(rows) <= 1:
        await context.bot.send_message(chat_id=chat_id, text="❌ *Jadval bo‘sh.*", parse_mode="Markdown")
        return

    total_students = len(rows) - 1
    total_active = 0
    total_per_w = Counter()
    active_per_w = Counter()

    for r in rows[1:]:
        w_val = safe_cell(r, IDX_W) or "Noma'lum"
        status = safe_cell(r, IDX_STAT)
        total_per_w[w_val] += 1
        if REQUIRED_STATUS.lower() in status.lower():
            active_per_w[w_val] += 1
            total_active += 1

    overall_pct = round((total_active / total_students * 100), 2) if total_students else 0.0

    lines = [
        "📊 *Statistika (W ustuni bo‘yicha):*\n",
        f"👥 *Jami talabalar:* {total_students} ta",
        f"🟢 *Faol shartnoma egalari (umumiy):* {total_active} ta ({overall_pct}%)\n",
    ]

    for w_key in sorted(total_per_w.keys(), key=lambda x: (x.lower() if isinstance(x, str) else str(x))):
        tot = total_per_w[w_key]
        act = active_per_w.get(w_key, 0)
        pct_group = round((act / tot * 100), 2) if tot else 0.0
        lines.append(f"▫️ *{escape_md(w_key)}:* jami {tot} | faol: {act} ({pct_group}%)")

    text = "\n".join(lines)

    # Eski sahifa xabari bo‘lsa — o‘chirib yuboramiz
    await _delete_prev_page_msg(chat_id, context)
    await context.bot.send_message(chat_id=chat_id, text=text, parse_mode="Markdown")

# Asosiy matnli qidiruv (reply tugmalarini ham ushlaydi)
async def search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    text = (update.message.text or "").strip()

    # Reply tugmalarini yo'naltirish
    if text == "🔎 Qidiruv":
        await update.message.reply_text("🔎 Qidiruv uchun: *ism/familiya (qismi)* yoki *HEMIS ID/JSHSHIR* yuboring.", parse_mode="Markdown")
        return
    if text == "📊 Statistika":
        await stat(update, context)
        return

    if not text:
        await update.message.reply_text("📝 Iltimos, matn yuboring.")
        return

    await context.bot.send_chat_action(chat_id=chat_id, action=ChatAction.TYPING)

    rows = load_rows()
    results = _build_results(text, rows)

    if not results:
        # Eski sahifa xabari bo‘lsa — o‘chirib yuboramiz
        await _delete_prev_page_msg(chat_id, context)
        await update.message.reply_text("❌ *Hech qanday ma'lumot topilmadi.*", parse_mode="Markdown")
        return

    # Keshga saqlaymiz
    CHAT_CACHE[chat_id] = {"query": text, "results": results, "page_msg_id": None}

    # 1-sahifani yuboramiz (oldingi xabar bo‘lsa — o‘chadi)
    await _send_page(chat_id, context, page=1)

# Inline pagination handler (◀️ / ▶️ tugmalari)
async def inline_pagination_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    cq = update.callback_query
    if not cq:
        return
    await cq.answer()

    chat_id = cq.message.chat_id
    data = cq.data  # format: "pg|<page>"
    try:
        _, raw_page = data.split("|", 1)
        page = int(raw_page)
    except Exception:
        return

    # Sahifani tahrirlab ko'rsatamiz
    await _edit_page(update, context, page)
