from telegram import ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton

def reply_main_menu():
    """Oddiy (inline emas) tugmalar — Qidiruv va Statistika."""
    keyboard = [
        ["🔎 Qidiruv", "📊 Statistika"]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)

def pagination_keyboard(current_page: int, total_pages: int):
    """Faqat ◀️ / ▶️ tugmalar. Callback data: pg|<page_number>."""
    prev_page = max(1, current_page - 1)
    next_page = min(total_pages, current_page + 1)

    btns = []
    # oldinga-orqaga holatiga qarab 1-2 tugma
    if current_page > 1:
        btns.append(InlineKeyboardButton("◀️", callback_data=f"pg|{prev_page}"))
    if current_page < total_pages:
        btns.append(InlineKeyboardButton("▶️", callback_data=f"pg|{next_page}"))

    # Agar faqat 1 sahifa bo'lsa — tugma bo‘lmasin
    if not btns:
        return None

    return InlineKeyboardMarkup([btns])
