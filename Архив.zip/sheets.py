import gspread
from google.oauth2.service_account import Credentials
from config import SHEET_ID, WORKSHEET_TITLE

SCOPE = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive",
]
CREDS = Credentials.from_service_account_file("credentials.json", scopes=SCOPE)
GC = gspread.authorize(CREDS)
WS = GC.open_by_key(SHEET_ID).worksheet(WORKSHEET_TITLE)

def load_rows():
    """Barcha qatordan (header bilan) qiymatlarni oladi (2D ro‘yxat)."""
    return WS.get_all_values()
