from typing import List

def safe_cell(row: List[str], idx: int) -> str:
    if idx < len(row) and row[idx] is not None:
        return str(row[idx]).strip()
    return ""

def escape_md(text: str) -> str:
    """
    Markdown uchun xavfsiz: *, _, ` belgilarini qochiramiz.
    """
    if text is None:
        return ""
    return (
        str(text)
        .replace("\\", "\\\\")
        .replace("_", "\\_")
        .replace("*", "\\*")
        .replace("`", "\\`")
    )
