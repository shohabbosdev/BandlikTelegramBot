from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters
from config import TOKEN
from handlers import start, stat, search, inline_pagination_handler

def main():
    app = Application.builder().token(TOKEN).build()

    # komandalar
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("stat", stat))

    # inline pagination tugmalari
    app.add_handler(CallbackQueryHandler(inline_pagination_handler, pattern=r"^pg\|"))

    # matnli qidiruv (reply tugmalar va oddiy matn)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, search))

    app.run_polling()

if __name__ == "__main__":
    main()
